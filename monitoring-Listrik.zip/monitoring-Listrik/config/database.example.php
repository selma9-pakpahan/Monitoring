<?php

defined('__IN_SCRIPT__') || exit(1);

define('DB_HOST', 'Your database host');
define('DB_USER', 'Your database user');
define('DB_NAME', 'Your database name');
define('DB_PASS', 'Your database password');
